package courseService;

import java.util.*;



public class Courses extends AbstractDisplay {

    private String description;
    private String instructorId;
    private List<Lesson> lessons;
    private List<String> students;

    public Courses() {
        lessons = new ArrayList<>();
        students = new ArrayList<>();
    }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getInstructorId() { return instructorId; }
    public void setInstructorId(String instructorId) { this.instructorId = instructorId; }

    public List<Lesson> getLessons() { return lessons; }
    public List<String> getStudents() { return students; }

    // Optional: convenience method to display number of lessons/students
    public int getLessonCount() { return lessons.size(); }
    public int getStudentCount() { return students.size(); }
}
